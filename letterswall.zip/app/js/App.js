var App = {};

App.Classes = {};

App.Objects = {};

App.JSON = {};
