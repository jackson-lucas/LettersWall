 Tecnologias utilizadas:
 - WebAudio API
 - Canvas API
 - Jquery
 - requestAnimationFrame()
 - CSS3 > flexbox, box-shadow, transform

 Benefício para a sociedade:
    Promover um jogo que testa a agilidade e o vocabulário do jogador. Instigando o jogador a conhecer mais palavras do nosso idioma.

Como jogar:
    Blocos com letras vão ficar caindo na tela. Clique nos blocos para formar palavras, clique no botão OK ou pressione Enter para ver se é uma palavra válida. Se for uma palavra os blocos serão eliminados. O seu objetivo é não os blocos preencherem a tela por completo.

O que ainda falta fazer:
    Ver arquivo list.TODO

Teste:
Teste apenas para computador, certas páginas não estão responsivas