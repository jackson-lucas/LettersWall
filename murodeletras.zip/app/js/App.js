var App = {};

App.Classes = {};

App.Objects = {};

App.Objects.background_volume = 0.5;
App.Objects.sounds_effects_volume = 0.5;

App.JSON = {};